#Hazard Nuker by Rdimooo
#### Hazard Nuker was made with
Love ❌ <br>
Code ✅

* ` Settings (Change the Color Theme, Thread Amount, Hotkeys and more!)`
* ` Both Compact and Feature-Rich`
* ` QoL Features such as Auto-Update, proxy scraping and more!`
* ` Easy to use!`
* ` Fast and Efficient (Low Performance Impact)`
* ` Linux Support! (Expect Bugs)`
* ` Create a token logger or QR code stealer!`
* ` Nuke an account!`
* ` Change an accounts Status, Bio, or HypeSquad house!`
* ` Mass DM using an account!`
* ` Log into an account with an isolated browser!`
* ` Mass Report a user or server!`
* ` Group Chat Spam!`
* ` Webhook Nuker/Deleter`
* ` And much, much more!`

## Features in detail

<details>
<summary>All features in detail! (Drop Down)</summary>

#### [1] Nuke a targetted account 
* Basically all account nuker-based options
* Uses **Everything**! (Mass DM, Create & Delete Servers, Change Language and Theme)
* It will remove all their friends and DMs as well
* Basically, it will shit on their account.
* Everything is logged in the command window, so you can see it all happening in real time

#### [2] Unfriend all friends
* Removes all friends from the victim

#### [3] Delete and leave all servers
* Leaves/Deletes any servers a user is in

#### [4] Spam Create New servers
* Creates 100 servers! 
* Can choose a server icon aswell as a name or have it pick a random one.

#### [5] DM Deleter
* Closes/Deletes all DMs with other users! (Will also leave group chats)

#### [6] Mass DM
* Message all friends of a user with a custom message!

#### [7] Enable seizure mode
* Switches between Light & Dark mode every second or so!
* Also cycles through all the languages.

#### [8] Get information from a targetted account
Returns a lot of user info based on a token!
* Username, Discriminator, Creation Date and other user info!
* Their personal info (such as Language, Creation Date, Email and more!)
* Their avatar URL, 2FA status, Nitro Info (Type & Days left, if they have Nitro)
* Payment method, and basic info about it (Address, Number, Payment Status, PayPal info if they use that)
* Geolocational Info, such as their Country, Region, City and more!
* And all the other info you could think of!

#### [9] Log into an account
* Log into a users account with their token!
* Supports Chrome, Edge, and Opera!

#### [10] Block Friends
* Blocks all their friends

#### [11] Profile Changer
* Allows you to modify their Status, Bio, and Hypequad Badge.

#### [12] COMING SOON!

#### [13] Create Token Grabber
Creates a token logger based off the **Hazard Stealer V2!**


#### [14] QR Code Grabber
Creates a QR code! If someone scans the QR code, you can gain access to their account!

#### [15] Mass Report
* Reports a user until you stop it.

#### [16] GroupChat Spammer
* Create a bunch of GCs with a specified user or random ones.

#### [17] Webhook Destroyer
* Spam & Delete any valid webhook!

#### [18] Settings
Change the following:
* Theme
* Threads
* Hotkeys
* Exit
</details>

---

## 🤓 Dear Skids
**Good for you,** you decided to skid something. <br>
We can't stop you, but just know you're pathetic. <br>
<br>
I hope you end up on the streets begging for spare change.

## Installation 

#### Source Code Version (More complicated but less buggy)
```sh-session
Click the green "Code" button.
Click "Download ZIP"
Extract the ZIP to a folder.

Run setup.bat, which will install all dependencies and open the script.
After that, every time you'd like to use Hazard, simply open start.bat

NOTE: Make sure you have Python 3.9.5 or above installed from python.org (NOT MICROSOFT) & added to path.
```

---

🌟 **Enjoyed Hazard Nuker?** Consider dropping a star :)



